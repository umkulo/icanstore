const express = require('express');
const router  = express.Router();
const db      = require('../config/database');
const Product = require('../models/Product');

//GET all
router.get('/', (req, res) => {
    Product.findAll()
        .then(products => res.render('products/', {
            products
        }))
        .catch(err => console.log(err))});

//GET display add form
router.get('/add', (req, res) => res.render('add'));

// ADD product
router.post('/add', (req, res) => {
    let { prod_Name, prod_Code, prod_Desc, 
        prod_Qty, prod_Price, prod_Disc
     } = req.body;
    let errors = [];
  
    Product.create({
        prod_Name, prod_Code, prod_Desc, 
        prod_Qty, prod_Price, prod_Disc
    })
      .then(product => res.redirect('/products'))
      .catch(err => console.log(err));
  });

module.exports = router;