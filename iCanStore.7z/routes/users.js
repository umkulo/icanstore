const express = require('express');
const router  = express.Router();
const db      = require('../config/database');
const User    = require('../models/User');
const Sequelize = require('sequelize');
const Op = Sequelize.Op;

//GET all
router.get('/', (req, res) => {
    User.findAll()
        .then(users => res.render('users/', {
            users
        }))
        .catch(err => console.log(err));
  });

//GET display add form
// router.get('/add', (req, res) => res.render('users'));

//Search users
router.get('/search', (req,res) => {
  const { term } = req.query;

  User.findAll({ where: {user_Surname: { [Op.like]: '%' + term + '%'}}})
    .then(users => res.render('users', { users }))
    .catch(err => console.log(err));
});

// ADD user
router.post('/add', (req, res) => {
    let { user_Name, user_Surname, user_Email, user_Cellphone, 
        user_Username, user_Password, role_ID, user_Active, 
        user_LastDate, user_MPNumber, user_PracticeNo } = req.body;
    let errors = [];
  
    // Validate Fields
    if(!user_Surname) {
      errors.push({ text: 'Please add at least a Surname' });
    }
    if(!user_Cellphone) {
      errors.push({ text: 'Please add a mobile number' });
    }
      
    // Check for errors
    if(errors.length > 0) {
      res.render('add', {
        errors,
        user_Name, user_Surname, user_Email, user_Cellphone, 
        user_Username, user_Password, role_ID, user_Active, 
        user_LastDate, user_MPNumber, user_PracticeNo
      });
    } 
 
    User.create({
      user_Name, user_Surname, user_Email, user_Cellphone, 
      user_Username, user_Password, role_ID, user_Active, 
      user_LastDate, user_MPNumber, user_PracticeNo
    })
      .then(user => res.redirect('/users'))
      .catch(err => console.log(err));
  });

// UPDATE user
router.post('/edit/(:id)', (req, res) => {
  let { user_Name, user_Surname, user_Email, user_Cellphone, 
      user_Username, user_Password, role_ID, user_Active, 
      user_LastDate, user_MPNumber, user_PracticeNo } = req.body;
  let errors = [];

  // Validate Fields
  if(!user_Surname) {
    errors.push({ text: 'Please add at least a Surname' });
  }
  if(!user_Cellphone) {
    errors.push({ text: 'Please add a mobile number' });
  }
    
  // Check for errors
  // if(errors.length > 0) {
    // res.render('add', {
      // errors,
      // user_Name, user_Surname, user_Email, user_Cellphone, 
      // user_Username, user_Password, role_ID, user_Active, 
      // user_LastDate, user_MPNumber, user_PracticeNo
    // });
  // } 

  User.update({
    user_Name, user_Surname, user_Email, user_Cellphone, 
    user_Username, user_Password, role_ID, user_Active, 
    user_LastDate, user_MPNumber, user_PracticeNo
  })
    .then(user => res.redirect('/users'))
    .catch(err => console.log(err));
});

router.get('/edit/(:id)', function(req, res, next){
    User.findAll({
        where: {
          user_ID: req.params.id
        }
      })
      .then(users => res.render('users/edit', {
          users
      }))
      .catch(err => console.log(err));
})

module.exports = router;

