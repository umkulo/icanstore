var express = require('express');
var router = express.Router();

/* GET Landing page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Landing Page' });
});

/* GET shop page. */
router.get('/shop', function(req, res, next) {
  res.render('shop/index', { title: 'iCanStore - Shop' });
});

/* GET products page. */
router.get('/product', function(req, res, next) {
  res.render('products/index', { title: 'Products' });
});

/* GET add product page. */
router.get('/product/add', function(req, res, next) {
  res.render('products/add', { title: 'Add Product' });
});

/* POST add product. */
router.post('/product/add', function(req, res, next) {
  res.render('products/add', { title: 'Add Product' });
});

/* GET Users page. */
router.get('/user', function(req, res, next) {
  res.render('users/index', { title: 'Users' });
});

/* GET add product page. */
router.get('/user/add', function(req, res, next) {
  res.render('users/add', { title: 'Add User' });
});

/* GET add product page. */
router.get('/user/edit', function(req, res, next) {
  res.render('users/edit', { title: 'Edit User' });
});

// /* UPDATE add product page. */
router.post('/user/edit/=?', function(req, res, next) {
  console.log('index');
  res.render('users/edit', { title: 'Edit User' });
});

module.exports = router;
